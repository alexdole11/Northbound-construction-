NORTHBOUND CONSTRUCTION & CONTRACTING WEBSITE

CONTENTS
- index.html: complete responsive website
- assets/: your logo, team photo, and project photos

PUBLISH WITH GITHUB PAGES
1. Open your GitHub repository.
2. Upload index.html and the entire assets folder (keep the folder name assets).
3. Commit the files to the main branch.
4. In the repository, open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select main and /(root), then Save.
7. Wait a few minutes and open the Pages URL shown in Settings > Pages.

IMPORTANT
- The estimate form opens the visitor's email app and prepares a message to Northboundcomi@gmail.com. It does not store or transmit form data itself.
- Replace or update photos by uploading new files into assets and changing the matching filenames in index.html.
- The website slogan is “Where the North Begins and the Pure Water Flows.” The About Us section emphasizes community and the promise to take on only work the company is proud to put its name on.
- The website currently uses the supplied contact details: 231-679-9606 and Northboundcomi@gmail.com.
- No license, insurance, warranty, or certification claims are made on the website.
